export const BlogData = [
    {
        id: 1,
        img: 'blog/blog-5.jpg',
        date: '9 April 2022',
        admin: 'by: Admin',
        hits: '0 Hits',
        details: 'Perspiciatis unde omnis iste natus error sit.Dummy text'
    },
    {
        id: 2,
        img: 'blog/blog-6.jpg',
        date: '9 April 2022',
        admin: 'by: Admin',
        hits: '0 Hits',
        details: 'Perspiciatis unde omnis iste natus error sit.Dummy text'
    },
    {
        id: 3,
        img: 'blog/blog-5.jpg',
        date: '9 April 2022',
        admin: 'by: Admin',
        hits: '0 Hits',
        details: 'Perspiciatis unde omnis iste natus error sit.Dummy text'
    },
    {
        id: 4,
        img: 'blog/blog-6.jpg',
        date: '9 April 2022',
        admin: 'by: Admin',
        hits: '0 Hits',
        details: 'Perspiciatis unde omnis iste natus error sit.Dummy text'
    }
];

export const BlogSingleData = [
    {
        id: 1,
        name: 'JolioMark',
        post: 'Designer',
        hits: '02 Hits',
        comments: '598 Comments',
        para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`
    },
    {
        id: 2,
        name: 'JolioMark',
        post: 'Designer',
        hits: '02 Hits',
        comments: '598 Comments',
        para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`
    },
    {
        id: 3,
        name: 'JolioMark',
        post: 'Designer',
        hits: '02 Hits',
        comments: '598 Comments',
        para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`
    },
    {
        id: 4,
        name: 'JolioMark',
        post: 'Designer',
        hits: '02 Hits',
        comments: '598 Comments',
        para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`
    },
    {
        id: 5,
        name: 'JolioMark',
        post: 'Designer',
        hits: '02 Hits',
        comments: '598 Comments',
        para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`
    }
];