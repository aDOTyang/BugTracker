import { Headphones, Home } from 'react-feather';

export const MENUITEMS = [
    {
        menutitle: 'General',
        menucontent: 'Dashboards,Widgets',
        Items: [
            {
                title: 'Dashboard', icon: Home, type: 'sub', active: false, children: [
                    { path: `${process.env.PUBLIC_URL}/dashboard/default`, title: 'Sample', type: 'link' },
                ]
            }
        ]
    },
    {
        menutitle: "Support",
        Items: [
            {
                title: 'Raise Support', icon: Headphones, type: 'sub', active: false, children: [
                    { title: 'Raise Ticket', type: 'exteral_link', path: 'http://support.pixelstrap.com/help-center' },
                ]
            }
        ]
    },
];