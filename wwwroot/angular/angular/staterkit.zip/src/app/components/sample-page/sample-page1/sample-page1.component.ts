import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample-page1',
  templateUrl: './sample-page1.component.html',
  styleUrls: ['./sample-page1.component.scss']
})
export class SamplePage1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
