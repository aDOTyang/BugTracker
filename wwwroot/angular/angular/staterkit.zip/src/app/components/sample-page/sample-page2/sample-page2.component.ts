import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample-page2',
  templateUrl: './sample-page2.component.html',
  styleUrls: ['./sample-page2.component.scss']
})
export class SamplePage2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
