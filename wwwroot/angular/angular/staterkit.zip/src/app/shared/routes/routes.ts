import { Routes } from '@angular/router';

export const content: Routes = [
  
   {
    path: 'sample-page',
    loadChildren: () => import('../../components/sample-page/sample-page.module').then(m => m.SamplePageModule),
    data: {
      title: "sample-page",
      breadcrumb: "sample-page"
    },
   },
];
