import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-chartist',
  templateUrl: './chartist.component.html',
  styleUrls: ['./chartist.component.scss']
})
export class ChartistComponent implements OnInit {
  

  constructor() { }

  ngOnInit(): void {
  }

}
