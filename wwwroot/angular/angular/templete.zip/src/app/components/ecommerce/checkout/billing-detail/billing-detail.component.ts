import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billing-detail',
  templateUrl: './billing-detail.component.html',
  styleUrls: ['./billing-detail.component.scss']
})
export class BillingDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
