import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-target',
  templateUrl: './our-target.component.html',
  styleUrls: ['./our-target.component.scss']
})
export class OurTargetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
