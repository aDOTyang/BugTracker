import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer-border-style',
  templateUrl: './offer-border-style.component.html',
  styleUrls: ['./offer-border-style.component.scss']
})
export class OfferBorderStyleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
