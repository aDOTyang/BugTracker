import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-input-groups',
  templateUrl: './basic-input-groups.component.html',
  styleUrls: ['./basic-input-groups.component.scss']
})
export class BasicInputGroupsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
