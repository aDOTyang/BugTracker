import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-animated-checkbox-btn',
  templateUrl: './animated-checkbox-btn.component.html',
  styleUrls: ['./animated-checkbox-btn.component.scss']
})
export class AnimatedCheckboxBtnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
