import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-border',
  templateUrl: './no-border.component.html',
  styleUrls: ['./no-border.component.scss']
})
export class NoBorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
