import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-style',
  templateUrl: './default-style.component.html',
  styleUrls: ['./default-style.component.scss']
})
export class DefaultStyleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
