import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-html-input-control',
  templateUrl: './basic-html-input-control.component.html',
  styleUrls: ['./basic-html-input-control.component.scss']
})
export class BasicHtmlInputControlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
