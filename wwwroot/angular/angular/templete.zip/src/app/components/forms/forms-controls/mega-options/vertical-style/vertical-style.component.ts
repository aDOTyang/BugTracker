import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vertical-style',
  templateUrl: './vertical-style.component.html',
  styleUrls: ['./vertical-style.component.scss']
})
export class VerticalStyleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
