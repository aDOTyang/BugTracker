import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-square-checkbox',
  templateUrl: './square-checkbox.component.html',
  styleUrls: ['./square-checkbox.component.scss']
})
export class SquareCheckboxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
