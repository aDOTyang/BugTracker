import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-solid-border-style',
  templateUrl: './solid-border-style.component.html',
  styleUrls: ['./solid-border-style.component.scss']
})
export class SolidBorderStyleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
