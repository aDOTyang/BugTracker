import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-animated-radio-btn',
  templateUrl: './animated-radio-btn.component.html',
  styleUrls: ['./animated-radio-btn.component.scss']
})
export class AnimatedRadioBtnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
