import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outline-button-group',
  templateUrl: './outline-button-group.component.html',
  styleUrls: ['./outline-button-group.component.scss']
})
export class OutlineButtonGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
