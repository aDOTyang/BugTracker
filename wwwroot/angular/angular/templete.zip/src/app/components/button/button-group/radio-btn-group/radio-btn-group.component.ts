import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-radio-btn-group',
  templateUrl: './radio-btn-group.component.html',
  styleUrls: ['./radio-btn-group.component.scss']
})
export class RadioBtnGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
