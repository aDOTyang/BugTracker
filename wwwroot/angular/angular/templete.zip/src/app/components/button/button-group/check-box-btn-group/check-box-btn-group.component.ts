import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-box-btn-group',
  templateUrl: './check-box-btn-group.component.html',
  styleUrls: ['./check-box-btn-group.component.scss']
})
export class CheckBoxBtnGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
