import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outline-flat-button',
  templateUrl: './outline-flat-button.component.html',
  styleUrls: ['./outline-flat-button.component.scss']
})
export class OutlineFlatButtonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
