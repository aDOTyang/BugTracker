import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outline-custom-btn-group2',
  templateUrl: './outline-custom-btn-group2.component.html',
  styleUrls: ['./outline-custom-btn-group2.component.scss']
})
export class OutlineCustomBtnGroup2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
