import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outline-edges-btn',
  templateUrl: './outline-edges-btn.component.html',
  styleUrls: ['./outline-edges-btn.component.scss']
})
export class OutlineEdgesBtnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
