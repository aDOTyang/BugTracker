import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outline-custom-btn-group',
  templateUrl: './outline-custom-btn-group.component.html',
  styleUrls: ['./outline-custom-btn-group.component.scss']
})
export class OutlineCustomBtnGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
