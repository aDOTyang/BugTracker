import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pearls-step-sizing',
  templateUrl: './pearls-step-sizing.component.html',
  styleUrls: ['./pearls-step-sizing.component.scss']
})
export class PearlsStepSizingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
