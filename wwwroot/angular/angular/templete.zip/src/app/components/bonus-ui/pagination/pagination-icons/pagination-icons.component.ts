import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagination-icons',
  templateUrl: './pagination-icons.component.html',
  styleUrls: ['./pagination-icons.component.scss']
})
export class PaginationIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
