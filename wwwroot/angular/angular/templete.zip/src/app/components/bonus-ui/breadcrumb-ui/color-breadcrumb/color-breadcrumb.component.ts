import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-color-breadcrumb',
  templateUrl: './color-breadcrumb.component.html',
  styleUrls: ['./color-breadcrumb.component.scss']
})
export class ColorBreadcrumbComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
