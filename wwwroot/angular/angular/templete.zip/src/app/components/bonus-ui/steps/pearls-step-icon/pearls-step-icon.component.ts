import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pearls-step-icon',
  templateUrl: './pearls-step-icon.component.html',
  styleUrls: ['./pearls-step-icon.component.scss']
})
export class PearlsStepIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
