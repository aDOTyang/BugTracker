import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagination-active-disabled',
  templateUrl: './pagination-active-disabled.component.html',
  styleUrls: ['./pagination-active-disabled.component.scss']
})
export class PaginationActiveDisabledComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
