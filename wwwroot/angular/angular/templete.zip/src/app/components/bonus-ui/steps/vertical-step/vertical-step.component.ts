import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vertical-step',
  templateUrl: './vertical-step.component.html',
  styleUrls: ['./vertical-step.component.scss']
})
export class VerticalStepComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
