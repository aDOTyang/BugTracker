import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagination-sizing',
  templateUrl: './pagination-sizing.component.html',
  styleUrls: ['./pagination-sizing.component.scss']
})
export class PaginationSizingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
