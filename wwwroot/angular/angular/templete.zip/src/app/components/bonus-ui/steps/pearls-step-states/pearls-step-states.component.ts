import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pearls-step-states',
  templateUrl: './pearls-step-states.component.html',
  styleUrls: ['./pearls-step-states.component.scss']
})
export class PearlsStepStatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
