import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-draggable-card',
  templateUrl: './draggable-card.component.html',
  styleUrls: ['./draggable-card.component.scss']
})
export class DraggableCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
